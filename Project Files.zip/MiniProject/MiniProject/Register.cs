﻿using System;
using System.Data.SqlClient;
using System.Reflection.Emit;
using System.Windows.Forms;

namespace MiniProject
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-19E1G1NG;Initial Catalog=MiniProject;Integrated Security=True");

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool ex = false;
            if (textBox1.Text == "") { label7.Visible = true; label8.Visible = false; label9.Visible = false; }
            else if (textBox2.Text == "") { label8.Visible = true; label7.Visible = false; label9.Visible = false; }
            else if (textBox3.Text == "") { label9.Visible = true; label8.Visible = false; label7.Visible = false; }
            else
            {
                if (textBox2.Text == textBox3.Text)
                {
                    con.Open();
                    SqlCommand comm = new SqlCommand("Select * from Sign_Up where user_n = @name", con);
                    comm.Parameters.AddWithValue("name", textBox1.Text.Trim());
                    SqlDataReader reader = comm.ExecuteReader();
                    if (reader.Read())
                    {
                        ex = true;
                    }
                    con.Close();
                    if (ex == false)
                    {
                        //Insert 
                        con.Open();
                        string query = "insert into Sign_Up values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')";
                        SqlCommand sqlCommand = new SqlCommand(query, con);
                        sqlCommand.ExecuteNonQuery();
                        con.Close();
                        Sign_in s_i = new Sign_in();
                        s_i.Show();
                        Visible = false;
                        MessageBox.Show("Register Sucessfully...");
                        //End
                    }
                    else { MessageBox.Show("User_name exist already..."); }
                }
                else
                {
                    MessageBox.Show("Confirm password does not matched...");
                }
            }

        }

        private void back_Click(object sender, EventArgs e)
        {
            Sign_in si = new Sign_in();
            si.Show();
            Visible = false;
        }
    }
}
