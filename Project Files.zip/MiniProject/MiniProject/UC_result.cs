﻿using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MiniProject
{
    public partial class UC_result : UserControl
    {
        static string Connectionstr = @"Data Source=LAPTOP-19E1G1NG;Initial Catalog=MiniProject;Integrated Security=True";
        public UC_result(string e)
        {
            InitializeComponent();
            SqlConnection con = new SqlConnection(Connectionstr);
            con.Open();
            SqlCommand comm = new SqlCommand("Select e_id from com where email_i = '" + e + "'", con);
            SqlDataReader reader = comm.ExecuteReader();
            if (reader.Read())
            {
                textBox4.Text = reader.GetString(0).ToString();
            }
            con.Close();
        }

        private void UC_result_Load(object sender, System.EventArgs e)
        {
                SqlConnection con = new SqlConnection(Connectionstr);
                con.Open();
                SqlCommand comm = new SqlCommand("select result.Votes, CANDIDATE.CANDIDATE_NAME, CANDIDATE.PARTY from result, vote, CANDIDATE where vote.e_id = 23 and vote.id = CANDIDATE.id;", con);
                SqlDataReader reader = comm.ExecuteReader();
                if (reader.Read())
                {
                    label12.Text = reader.GetInt32(0).ToString();
                    textBox1.Text = reader.GetString(1).ToString();
                    textBox5.Text = reader.GetString(2).ToString();
                }
                con.Close();

                SqlConnection con1 = new SqlConnection(Connectionstr);
                con1.Open();
                SqlCommand com1 = new SqlCommand("select  CANDIDATE.PARTY, result.Votes from CANDIDATE, result where CANDIDATE.id = (select id from result where Votes = (select MAX(Votes) from result));", con1);
                SqlDataReader reader1 = com1.ExecuteReader();
                if (reader1.Read())
                {
                    textBox6.Text = reader1.GetString(0).ToString();
                    label13.Text = reader1.GetInt32(1).ToString();
                }
                con1.Close();

                SqlConnection con2 = new SqlConnection(Connectionstr);
                con2.Open();
                SqlCommand cmd2 = new SqlCommand("select CANDIDATE.id, CANDIDATE.CANDIDATE_NAME, CANDIDATE.PARTY, result.Votes from CANDIDATE, result where CANDIDATE.id = result.id;", con2);
                DataTable dt = new DataTable();
                dt.Load(cmd2.ExecuteReader());
                dataGridView1.DataSource = dt;
                con2.Close();

                SqlConnection con3 = new SqlConnection(Connectionstr);
                con3.Open();
                SqlCommand cmd3 = new SqlCommand("select Sum(result.Votes) as Total_Votes from result;", con3);
                SqlDataReader rd = cmd3.ExecuteReader();
                if (rd.Read())
                {
                    label15.Text = rd.GetInt32(0).ToString();
                }
                con3.Close();
            
        }
    }
}
