﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MiniProject
{
    public partial class UserC : Form
    {
        static UserC obj;
        public static UserC Instance 
        {
            get {
                if(obj == null) {
                    obj = new UserC(v);
                }
                return obj;
            }
        } 

        public Panel PnlContainer {
            get { return panelContainer; }
            set { panelContainer = value; }
        }

        public Button BackBottom {
            get { return back; }
            set { back = value; }
        }
        public static string v;
        public UserC(string val) {    InitializeComponent(); v = val; }

        private void UserC_Load(object sender, EventArgs e) {
            back.Visible = false;
            obj = this;

            UC_Home uH = new UC_Home();
            uH.Dock = DockStyle.Fill;
            panelContainer.Controls.Add(uH);
        }

        private void back_Click(object sender, EventArgs e) {
            UserC.Instance.PnlContainer.Controls["UC_Home"].BringToFront();
            UserC.Instance.BackBottom.Visible = false;
        }
        
        private void button1_Click(object sender, EventArgs e) {
            if (!UserC.Instance.PnlContainer.Controls.ContainsKey("UC_Voter")) {
                UC_Voter uc_v = new UC_Voter(v);
                uc_v.Dock = DockStyle.Fill;
                UserC.Instance.PnlContainer.Controls.Add(uc_v);
            }
            UserC.Instance.PnlContainer.Controls["UC_Voter"].BringToFront();
            UserC.Instance.BackBottom.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e) {
            if (!UserC.Instance.PnlContainer.Controls.ContainsKey("UC_Candidate")) {   
                UC_Candidate uc_C = new UC_Candidate(v);
                uc_C.Dock = DockStyle.Fill;
                UserC.Instance.PnlContainer.Controls.Add(uc_C);
            }
            UserC.Instance.PnlContainer.Controls["UC_Candidate"].BringToFront();
            UserC.Instance.BackBottom.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e) {
            SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-19E1G1NG;Initial Catalog=MiniProject;Integrated Security=True");
            con.Open();
            SqlCommand com = new SqlCommand("Select result_S from Show", con);
            SqlDataReader reader = com.ExecuteReader();
            if (reader.Read())
            {
                if (reader.GetString(0).ToString()=="YES")
                {
                    if (!UserC.Instance.PnlContainer.Controls.ContainsKey("UC_Result"))
                    {
                        UC_result uc_r = new UC_result(v);
                        uc_r.Dock = DockStyle.Fill;
                        UserC.Instance.PnlContainer.Controls.Add(uc_r);
                    }
                    UserC.Instance.PnlContainer.Controls["UC_Result"].BringToFront();
                    UserC.Instance.BackBottom.Visible = true;
                }
                else
                {
                    MessageBox.Show("Result Not Published Yet!!!", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Question);
                }
            }
            con.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Maximized) { WindowState = FormWindowState.Normal; }
            else { WindowState = FormWindowState.Maximized; }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Sign_in sign_In = new Sign_in();
            sign_In.Show();
            Visible = false;
        }
    }
}
