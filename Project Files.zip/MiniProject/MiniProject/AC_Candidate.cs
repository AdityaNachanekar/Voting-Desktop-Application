﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace MiniProject
{
    public partial class AC_Candidate : UserControl
    {
        string imgurl = "";
        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-19E1G1NG;Initial Catalog=MiniProject;Integrated Security=True");

        public AC_Candidate()
        {
            InitializeComponent();
        }

        private void AC_Candidate_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from CANDIDATE", con);
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            dataGridView1.RowTemplate.Height = 200;
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image == null)
            {
                OpenFileDialog open = new OpenFileDialog();
                open.Filter = "Image Files(*.jpeg; *.jpg; *.png;)|*.jpeg; *.jpg; *.png; ";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    imgurl = open.FileName;
                    pictureBox1.Image = new Bitmap(open.FileName);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool ex = true;
            if (textBox1.Text == "") { label4.Visible = true; label5.Visible = false; label6.Visible = false; }
            else if (textBox4.Text == "") { label5.Visible = true; label4.Visible = false; label6.Visible = false; }
            else if (textBox6.Text == "") { label6.Visible = true; label5.Visible = false; label4.Visible = false; }
            else
            {
                con.Open();
                SqlCommand comm = new SqlCommand("Select * from CANDIDATE where id = @id", con);
                comm.Parameters.AddWithValue("id", textBox1.Text.Trim());
                SqlDataReader reader = comm.ExecuteReader();
                if (reader.Read())
                {
                    ex = false;
                }
                con.Close();
                if (ex)
                {
                    Image img = pictureBox1.Image;
                    byte[] arr;
                    ImageConverter converter = new ImageConverter();
                    arr = (byte[])converter.ConvertTo(img, typeof(byte[]));
                    try
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("insert into CANDIDATE values('" + textBox1.Text + "',(SELECT * FROM OPENROWSET(BULK '" + imgurl + "',SINGLE_BLOB)AS IMAGE),'" + textBox6.Text + "', '" + textBox4.Text + "')", con);
                        cmd.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("Done");
                        textBox4.Enabled = false;
                        textBox6.Enabled = false;
                    }
                    catch (Exception exc) { MessageBox.Show("Something went wrong...", "Caution", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                }
                else
                {
                    MessageBox.Show("Candidate data Already Exists!!!");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("delete from CANDIDATE where id = '"+textBox1.Text.Trim()+"'", con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("ID = "+textBox1.Text+" data is Deleted Successfully...");
                textBox1.Text = "";
                textBox4.Text = "";
                textBox6.Text = "";
                pictureBox1.Image = null;
            }
            catch (Exception exc) { MessageBox.Show("Something went wrong...", "Caution", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "") { textBox4.Text = ""; textBox6.Text = ""; pictureBox1.Image = null; }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("select PARTY, CANDIDATE_NAME, PARTY_SYMBOL from CANDIDATE where id = '" + textBox1.Text.Trim() + "'", con);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        textBox4.Enabled = false;
                        textBox6.Enabled = false;
                        textBox4.Text = dr.GetString(1).ToString();
                        textBox6.Text = dr.GetString(0).ToString();
                        byte[] img = (byte[])dr.GetValue(2);
                        MemoryStream ms = new MemoryStream(img);
                        pictureBox1.Image = Image.FromStream(ms);
                    }
                    else {
                        textBox4.Enabled = true;
                        textBox6.Enabled = true;
                    }
                    con.Close();
                }
                catch (Exception exc) { MessageBox.Show("Something went wrong...", "Caution", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }
    }
}