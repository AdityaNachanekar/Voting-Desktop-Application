﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MiniProject
{
    public partial class Forgetpass : Form
    {
        public Forgetpass()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-19E1G1NG;Initial Catalog=MiniProject;Integrated Security=True");
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool ex = false;
            if(textBox1.Text == "") { label7.Visible = true;label8.Visible = false;label9.Visible = false; label10.Visible = false; }
            else if(textBox2.Text == "") { label8.Visible = true; label7.Visible = false; label9.Visible = false; label10.Visible = false; }
            else if(textBox3.Text == "") { label9.Visible = true; label10.Visible = false; label8.Visible = false; label7.Visible = false; }
            else if (textBox4.Text == "") { label10.Visible = true; label9.Visible = false; label8.Visible = false; label7.Visible = false; }
            else
            {
                if (textBox4.Text == textBox5.Text)
                {
                    if (textBox2.Text == textBox3.Text)
                    {
                        con.Open();
                        SqlCommand comm = new SqlCommand("Select * from Sign_Up where user_n = @name", con);
                        comm.Parameters.AddWithValue("name", textBox1.Text.Trim());
                        SqlDataReader reader = comm.ExecuteReader();
                        if (reader.Read())
                        {
                            ex = true;
                        }
                        con.Close();
                        if (ex)
                        {
                            //Update query
                            label10.Visible = false;
                            string query = "update Sign_Up set pass = '" + textBox2.Text + "', cpass = '" + textBox3.Text + "' where user_n = '" + textBox1.Text + "'";
                            con.Open();
                            SqlCommand cmd = con.CreateCommand();
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandText = query;
                            cmd.ExecuteNonQuery();
                            con.Close();
                            MessageBox.Show("Password Changed Successfully","Password Changed",MessageBoxButtons.OK,MessageBoxIcon.Information);
                            Sign_in sign_In = new Sign_in();
                            sign_In.Show();
                            Visible = false;
                            //End
                        }
                        else
                        {
                            MessageBox.Show("Email Id does not exists...");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Confirm password does not matched...");
                    }
                }
                else
                {
                    label10.Visible = true;
                }
            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            Sign_in si = new Sign_in();
            si.Show();
            Visible = false;
        }
    }
}
