﻿using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MiniProject
{
    public partial class UC_Candidate : UserControl
    {
        static string Connectionstr = @"Data Source=LAPTOP-19E1G1NG;Initial Catalog=MiniProject;Integrated Security=True";

        public bool ex = false;
        public UC_Candidate(string e)
        {
            InitializeComponent();
            SqlConnection con = new SqlConnection(Connectionstr);
            con.Open();
            SqlCommand comm = new SqlCommand("Select e_id from com where email_i = '"+e+"'", con);
            SqlDataReader reader = comm.ExecuteReader();
            if (reader.Read())
            {
                textBox2.Text = reader.GetString(0).ToString();
            }  
            con.Close();
            SqlConnection con1 = new SqlConnection(Connectionstr);
            con1.Open();
            SqlCommand cmd = new SqlCommand("select e_id, id from vote where e_id = '" + textBox2.Text.Trim() + "'", con1);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                ex = true;
                textBox1.Text = dr.GetInt32(1).ToString();
                textBox1.Enabled = false;
            }
            con1.Close();
        }

        private void UC_Candidate_Load(object sender, System.EventArgs e)
        {
            SqlConnection con = new SqlConnection(Connectionstr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from CANDIDATE", con);
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            dataGridView1.RowTemplate.Height = 200;
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void textBox1_TextChanged(object sender, System.EventArgs e)
        {
            if (textBox1.Text == "") { textBox4.Text = ""; textBox6.Text = ""; }
            else { 
                SqlConnection con = new SqlConnection(Connectionstr);
                con.Open();
                SqlCommand cmd = new SqlCommand("select PARTY, CANDIDATE_NAME from CANDIDATE where id = '" + textBox1.Text.Trim() + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    textBox4.Text = dr.GetString(1).ToString();
                    textBox6.Text = dr.GetString(0).ToString();
                }
                con.Close();
            }
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            if (textBox1.Text == "") { label3.Visible = true; }
            else
            {
                if (ex)
                {
                    MessageBox.Show("You have already voted...");
                }
                else { 
                    SqlConnection con = new SqlConnection(Connectionstr);
                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into vote values('" + textBox2.Text + "','" + textBox1.Text + "')", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Done");
                    ex = true;
                    textBox1.Enabled = false;
                }
            }
        }
    }
}
