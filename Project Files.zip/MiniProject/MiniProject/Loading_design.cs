﻿using System;
using System.Windows.Forms;

namespace MiniProject
{
    public partial class Loading_design : Form
    {
        public Loading_design()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            panel2.Width += 3;
            if(panel2.Width >= 781) 
            {
                timer1.Stop();
                Sign_in si = new Sign_in();
                si.Show();
                Visible = false;
            }
        }
    }
}
