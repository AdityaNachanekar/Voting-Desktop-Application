﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiniProject
{
    public partial class AC_sresult : UserControl
    {
        public AC_sresult()
        {
            InitializeComponent();
        }
    }
}
