﻿using System.Windows.Forms;

namespace MiniProject
{
    public partial class UC_Home : UserControl
    {
        public UC_Home()
        {
            InitializeComponent();
        }
    }
}
