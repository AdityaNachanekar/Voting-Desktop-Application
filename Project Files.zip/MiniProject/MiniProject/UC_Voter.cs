﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MiniProject
{
    public partial class UC_Voter : UserControl
    {
        string imgurl = "";
        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-19E1G1NG;Initial Catalog=MiniProject;Integrated Security=True");

        public UC_Voter(string val)
        {
            InitializeComponent();
            textBox5.Text = val;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image == null)
            {
                OpenFileDialog open = new OpenFileDialog();
                open.Filter = "Image Files(*.jpeg; *.jpg; *.png;)|*.jpeg; *.jpg; *.png; ";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    imgurl = open.FileName;
                    pictureBox1.Image = new Bitmap(open.FileName);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool ex = true;
            if (textBox1.Text == "") { label6.Visible = true; label7.Visible = false; label8.Visible = false; label9.Visible = false; label12.Visible = false; }
            else if (date.Text == "") { label7.Visible = true; label8.Visible = false; label9.Visible = false; label6.Visible = false; label12.Visible = false; }
            else if (textBox3.Text == "") { label8.Visible = true; label9.Visible = false; label7.Visible = false; label6.Visible = false; label12.Visible = false; }
            else if (textBox4.Text == "") { label9.Visible = true; label8.Visible = false; label6.Visible = false; label7.Visible = false; label12.Visible = false; }
            else if (textBox5.Text == "") { label12.Visible = true; label8.Visible = false; label6.Visible = false; label7.Visible = false; label9.Visible = false; }
            else
            {
                DateTime d = (Convert.ToDateTime(date.Text.ToString()));
                int a = CalculateYourAge(d);
                if (a >= 18)
                {
                    con.Open();
                    SqlCommand comm = new SqlCommand("Select * from Voters where e_id = @eid", con);
                    comm.Parameters.AddWithValue("eid", textBox4.Text.Trim());
                    SqlDataReader reader = comm.ExecuteReader();
                    if (reader.Read())
                    {
                        ex = false;
                    }
                    con.Close();
                    if (ex)
                    {
                        DialogResult dia = MessageBox.Show("Are you sure to proceed?","Confirmation",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
                        if (dia == DialogResult.Yes)
                        {
                            Image img = pictureBox1.Image;
                            byte[] arr;
                            ImageConverter converter = new ImageConverter();
                            arr = (byte[])converter.ConvertTo(img, typeof(byte[]));
                            try
                            {
                                con.Open();
                                SqlCommand cmd = new SqlCommand("insert into Voters values('" + textBox1.Text + "', '" + date.Text + "', '" + textBox3.Text + "','" + textBox4.Text + "','" + arr + "', '" + textBox5.Text + "','" + a + "')", con);
                                cmd.ExecuteNonQuery();
                                con.Close();
                                MessageBox.Show("Done");
                                Age.Text = (Convert.ToString(a));
                            }
                            catch (Exception exc) { MessageBox.Show("Something went wrong...", "Caution", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                            textBox1.Enabled = false;
                            date.Enabled = false;
                            textBox3.Enabled = false;
                            textBox4.Enabled = false;
                        }
                    }
                    else { MessageBox.Show("Election ID Exists"); }
                }
                else { 
                    MessageBox.Show("You are not Eligible to Vote.");
                    try
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("delete from Sign_Up where user_n = '" + textBox5.Text.Trim() + "';", con);
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }catch (Exception exc) { MessageBox.Show("Something went wrong...", "Caution", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                    Sign_in si = new Sign_in();
                    si.Show();
                    Visible = false;
                }
            }
        }

        static int CalculateYourAge(DateTime Dob)
        {
            DateTime Now = DateTime.Now;
            int Years = new DateTime(DateTime.Now.Subtract(Dob).Ticks).Year - 1;
            return Years;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            bool ex = false;
            con.Open();
            SqlCommand comm = new SqlCommand("Select email_i from Voters where email_i = @name", con);
            comm.Parameters.AddWithValue("name", textBox5.Text.Trim());
            SqlDataReader reader = comm.ExecuteReader();
            if (reader.Read())
            {
                ex = true;
            }
            con.Close();
            if (ex)
            {
                con.Open();
                SqlCommand sqlCommand = new SqlCommand("select v_name, dob, aadh, e_id, age from com where email_i = '" + textBox5.Text + "';", con);
                SqlDataReader reader1 = sqlCommand.ExecuteReader();
                while (reader1.Read())
                {
                    textBox1.Text = reader1.GetString(0).ToString();
                    date.Text = reader1.GetDateTime(1).ToString();
                    textBox3.Text = reader1.GetString(2).ToString();
                    textBox4.Text = reader1.GetString(3).ToString();
                    Age.Text = reader1.GetInt32(4).ToString();
                }
                con.Close();
                textBox1.Enabled = false;
                date.Enabled = false;
                textBox3.Enabled = false;
                textBox4.Enabled = false;
                label10.Visible = false;
                pictureBox2.Visible = false;
            }
            else
            {
                label10.Visible = true;
                pictureBox2.Visible = true;
            }
        }
    }
}
