﻿using System;
using System.Windows.Forms;

namespace MiniProject
{
    public partial class AdminUI : Form
    {
        static AdminUI obj;
        public static AdminUI Instance
        {
            get
            {
                if (obj == null)
                {
                    obj = new AdminUI();
                }
                return obj;
            }
        }

        public Panel PnlContainer
        {
            get { return AdminpanelContainer; }
            set { AdminpanelContainer = value; }
        }

        public Button BackBottom
        {
            get { return back; }
            set { back = value; }
        }

        public AdminUI() { InitializeComponent(); }

        private void AdminUI_Load(object sender, EventArgs e)
        {
            back.Visible = false;
            obj = this;

            UC_Home home = new UC_Home();
            home.Dock = DockStyle.Fill;
            AdminpanelContainer.Controls.Add(home);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Sign_in sign_In = new Sign_in();    
            sign_In.Show();
            Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!UserC.Instance.PnlContainer.Controls.ContainsKey("AC_Candidate"))
            {
                AC_Candidate ac_c = new AC_Candidate();
                ac_c.Dock = DockStyle.Fill;
                AdminUI.Instance.PnlContainer.Controls.Add(ac_c);
            }
            AdminUI.Instance.PnlContainer.Controls["AC_Candidate"].BringToFront();
            AdminUI.Instance.BackBottom.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!UserC.Instance.PnlContainer.Controls.ContainsKey("AU_result"))
            {
                AU_result ac_r = new AU_result();
                ac_r.Dock = DockStyle.Fill;
                AdminUI.Instance.PnlContainer.Controls.Add(ac_r);
            }
            AdminUI.Instance.PnlContainer.Controls["AU_result"].BringToFront();
            AdminUI.Instance.BackBottom.Visible = true;
        }

        private void back_Click(object sender, EventArgs e)
        {
            AdminUI.Instance.PnlContainer.Controls["UC_Home"].BringToFront();
            AdminUI.Instance.BackBottom.Visible = false;
        }
    }
}
