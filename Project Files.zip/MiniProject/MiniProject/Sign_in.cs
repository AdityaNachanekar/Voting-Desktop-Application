﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MiniProject
{
    public partial class Sign_in : Form
    {
        string u = "";
        public Sign_in()
        {
            InitializeComponent();
        }

        static string connectionstr = @"Data Source=LAPTOP-19E1G1NG;Initial Catalog=MiniProject;Integrated Security=True";

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connectionstr);
            if (textBox1.Text == "") { label7.Visible = true;
                label8.Visible = false;
            }
            else if (textBox2.Text == "") { label8.Visible = true; label7.Visible = false; }
            else
            {
                label7.Visible = false;
                label8.Visible = false;
                try
                {
                    u = textBox1.Text;
                    string query = "select * from Sign_Up where user_n = '" + textBox1.Text + "' and pass = '" + textBox2.Text + "'";
                    SqlDataAdapter sda = new SqlDataAdapter(query, con);

                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        UserC uc = new UserC(u);
                        uc.Show();
                        Visible = false;
                        MessageBox.Show("You are Successfully SignIn");
                    }
                    else
                    {
                        MessageBox.Show("User name or password is incorrect!");
                    }
                }
                catch { MessageBox.Show("Some Error Occur..."); }
                finally { con.Close(); }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Register r = new Register();
            r.Show();
            Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Admin a = new Admin();
            a.Show();
            Visible = false;
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Forgetpass fp = new Forgetpass();
            fp.Show();
            Visible = false;
        }
    }
}
