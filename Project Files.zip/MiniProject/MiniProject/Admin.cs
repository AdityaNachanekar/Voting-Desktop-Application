﻿using System;
using System.Windows.Forms;

namespace MiniProject
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Sign_in s_i = new Sign_in();
            s_i.Show();
            Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "GPM" && textBox2.Text == "gpmumba")
            {
                AdminUI aui = new AdminUI();
                aui.Show();
                Visible = false;
            }
            else { MessageBox.Show("Invalid User name or Password..."); }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }
    }
}
