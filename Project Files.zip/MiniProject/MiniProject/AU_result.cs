﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiniProject
{
    public partial class AU_result : UserControl
    {
        public AU_result()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ch = "NO";
            if(radioButton1.Checked == true) { ch = radioButton1.Text;
            }
            MessageBox.Show("Value set to " + ch, "INFO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-19E1G1NG;Initial Catalog=MiniProject;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("update Show set result_S = '" + ch + "';",con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
